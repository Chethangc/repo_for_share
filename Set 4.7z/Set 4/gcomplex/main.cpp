#include <iostream>

using namespace std;

template<typename T>
class Complex {
  T m_real;
  T m_image;
  public:
  Complex();
  Complex(T,T);
  void display();
};

template<typename T>
Complex<T>::Complex():m_real(0),m_image(0){}
template<typename T>
Complex<T>::Complex(T r,T i):m_real(r),m_image(i){}
template<typename T>
void Complex<T>::display()
{
    cout<<m_real<<"+"<<m_image<<"i"<<endl;
}

int main()
{
    Complex<int> c;
    c.display();
    Complex<int> x(10,10);
    x.display();
    return 0;
}

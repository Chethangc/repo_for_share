#include <iostream>
using namespace std;

template<typename T>
class MyArray {
  int *m_arr;
  int m_len;
  public:
  MyArray();
  explicit MyArray(int len);
  ~MyArray();
  void append(T val);
  T at(int index);
  bool search(T key) const;
  T sum() const;
  T min() const;
  T max() const;
  void reverse();
  void sort();
};
template <typename T>
void MyArray<T>::reverse(){
    int *temp1 = m_arr, *temp2 = m_arr + (sizeof(m_arr)/sizeof(m_arr[0])) - 1;
    while (temp1 < temp2) {
         int temp = *temp1;
        *temp1 = *temp2;
        *temp2 = temp;
        temp1++;
        temp2--;
    }
}
template <typename T>
void MyArray<T>::sort(){
    int temp;
for(int i=0;i<(sizeof(m_arr)/sizeof(m_arr[0]));i++)
{
		for(int j=i+1;j<(sizeof(m_arr)/sizeof(m_arr[0]));j++)
		{
			if(m_arr[i]>m_arr[j])
			{
				temp  =m_arr[i];
				m_arr[i]=m_arr[j];
				m_arr[j]=temp;
			}
		}
	}
}


template <typename T>
T MyArray<T>::at(int index){
if(m_len!=(sizeof(m_arr)/sizeof(m_arr[0])))
{
    return m_arr[index];
}

}
template <typename T>
T MyArray<T>::sum() const{
    T sum=0;
 for(int i=0;i<(sizeof(m_arr)/sizeof(m_arr[0]));i++)
      {
          sum+=m_arr[i];
      }
      return sum;
}
template <typename T>
T MyArray<T>::max() const{
    T max=0;
 for(int i=0;i<(sizeof(m_arr)/sizeof(m_arr[0]));i++)
      {
          if(m_arr[i]>max)
          {
              max=m_arr[i];
          }
      }
      return max;

}
template <typename T>
T MyArray<T>::min() const{
    T min=m_arr[0];
 for(int i=0;i<(sizeof(m_arr)/sizeof(m_arr[0]));i++)
      {
          if(m_arr[i]<min)
          {
              min=m_arr[i];
          }
      }
      return min;
}
template<typename T>
MyArray<T>::MyArray() : m_arr(nullptr), m_len(0){}
template<typename T>
MyArray<T>::MyArray(int len) : m_len(len) {
    m_arr = new int[m_len];
}
template<typename T>
MyArray<T>::~MyArray() {
     if (m_arr != nullptr)
      delete[] m_arr;
}
template<typename T>
void MyArray<T>::append(T val)
{
  if(m_len!=0)
  {m_arr[m_len%(sizeof(m_arr)/sizeof(m_arr[0]))]=val;
  m_len--;}
  else
  {

  }
}
template <typename T>
bool MyArray<T>::search(T key) const{
 for(int i=0;i<(sizeof(m_arr)/sizeof(m_arr[0]));i++)
      {
          if(m_arr[i]==key)
            {return true;}
          else
            {return false;}
      }
}


int main()
{
    MyArray<int> A(2);
    A.append(2);
    A.append(1);
    A.append(3);
    A.search(8);
    A.sort();
    cout<<A.at(0);
    cout<<A.at(1);
    A.reverse();
    cout<<A.at(0);
    cout<<A.at(1)<<A.min()<<A.max()<<A.sum();
    return 0;
}

#include <iostream>

constexpr int max_size=50;

template<typename T>
class MyStack {
  T m_arr[max_size];
  int m_top;
  int m_maxlen;
  public:
  MyStack();
  explicit MyStack(int len);
  void push(T val);
  T pop();
  T peek() const;
  bool isEmpty() const;
  bool isFull() const;
};
template<typename T>
 bool MyStack<T>::isEmpty() const
 {

     if(m_top==-1)
     {
         return true;
     }
     else
     {

        return false;
     }
 }
  template<typename T>
 bool MyStack<T>::isFull() const
 {
     if(m_top>=m_maxlen-1)
     {
         return true;
     }
     else
     {
        return false;
     }
 }
template<typename T>
MyStack<T>::MyStack()
{
     for(int i=0;i<max_size;i++)
    {
        m_arr[i]=-1;
    }
    m_top=-1;
    m_maxlen=max_size;
}

template<typename T>
MyStack<T>::MyStack(int len)
{
    for(int i=0;i<len;i++)
    {
        m_arr[i]=-1;
    }
    m_top=-1;
    m_maxlen=len;
}

template<typename T>
void MyStack<T>::push(T val)
{
    if(MyStack<T>::isEmpty()){
     //std::cout<<m_top<<std::endl;
     m_top=m_top+1;
     //std::cout<<m_top<<std::endl;
     m_arr[m_top]= val;
     //m_top+=1;
     //std::cout<<m_arr[m_top];
     //std::cout<<"push";
    }
    else if(MyStack<T>::isFull())
    {
        std::cout<<"Stack Full"<<std::endl;
    }
    else
    {
        m_top=m_top+1;
        m_arr[m_top]=val;

        //std::cout<<"push"<<std::endl;
    }
}

template<typename T>
T MyStack<T>::peek() const
{
    if(!MyStack::isEmpty())
    {
    return (m_arr[m_top]);
    }
    else
    {
        return -1;
    }
}

template<typename T>
T MyStack<T>::pop()
{
    if(!MyStack::isEmpty())
    {
    int a=m_arr[m_top];
    m_top--;
    return a;
    }
    else
    {
        return -1;
    }
}




int main()
{
    MyStack<int> s(10);
    s.pop();
    s.push(1);
    s.push(2);
    s.push(3);
    s.push(4);
    s.push(5);
    s.push(6);
    s.push(7);
    s.push(8);
    s.push(9);
    s.push(10);
    s.push(11);
    std::cout<<s.pop()<<std::endl;
    std::cout<<s.peek()<<std::endl;
    std::cout<<s.pop()<<std::endl;
    std::cout<<s.peek()<<std::endl;
    s.push(10);
    std::cout<<s.peek()<<std::endl;
    return 0;
}



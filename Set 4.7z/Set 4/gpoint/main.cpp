#include <iostream>
#include <math.h>
using namespace std;

enum Quadrant {
  Q1,
  Q2,
  Q3,
  Q4
};


template<typename T>
class Point {
  T m_x;
  T m_y;
  public:
  Point();
  Point(T,T);
  void distanceFromOrigin();
  Quadrant quadrant();
  void display();
};

template<typename T>
Point<T>::Point():m_x(0),m_y(0){}
template<typename T>
Point<T>::Point(T x,T y):m_x(x),m_y(y){}

template<typename T>
void Point<T>::distanceFromOrigin()
{
std::cout<<sqrt(pow(m_x,2)+pow(m_y,2)*1.0);
}
template<typename T>
void Point<T>::display()
{
std::cout<<"Point:"<<"("<<m_x<<","<<m_y<<")"<<endl;
}
template<typename T>
Quadrant Point<T>::quadrant()
{
if(m_x>0 && m_y>0)
    return Q1;
else if(m_x>0 && m_y<0)
    return Q2;
else if(m_x<0 && m_y<0)
    return Q3;
else
    return Q4;
}
int main()
{
    Point<int> p;
    Point<int> p1(1,1);
    p.display();
    p1.display();
    p1.distanceFromOrigin();
    switch(p1.quadrant())
    {
        case Q1: std::cout<<"Q1";break;
        case Q2: std::cout<<"Q2";break;
        case Q3: std::cout<<"Q3";break;
        case Q4: std::cout<<"Q4";break;
    }
}
